#include <stdio.h>

int main(int argc, char **argv) {

	//printf("Hello world!\n");

	int i;
	for (i = 1; i < 16; i++)
		printf("#%d FSE2020-1 MARTINEZ ENRIQUE\n",i);

	return 0;
}
